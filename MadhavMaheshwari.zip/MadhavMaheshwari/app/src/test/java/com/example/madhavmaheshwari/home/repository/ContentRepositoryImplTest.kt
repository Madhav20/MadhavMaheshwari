package com.example.madhavmaheshwari.home.repository

import app.cash.turbine.test
import com.example.madhavmaheshwari.TestCoroutineRule
import com.example.madhavmaheshwari.dispatcherProvider
import com.example.madhavmaheshwari.home.ContentApi
import com.example.madhavmaheshwari.utils.Status
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.runTest
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.mockito.Mock
import org.mockito.MockitoAnnotations
import org.mockito.kotlin.whenever
import retrofit2.Response

@ExperimentalCoroutinesApi
class ContentRepositoryImplTest {
    @get:Rule
    val dispatcherRule = TestCoroutineRule()

    private lateinit var repository: ContentRepository

    @Mock
    private lateinit var api: ContentApi

    @Before
    fun setUp() {
        MockitoAnnotations.openMocks(this)
        repository = ContentRepositoryImpl(api, dispatcherProvider)
    }

    @Test
    fun `fetchWebContent() should emit Loading, then Success when API call is successful`() =
        runTest {
            val mockResponse = Response.success("Mocked HTML Content")
            whenever(api.fetchWebContent()).thenReturn(mockResponse)

            repository.fetchWebContent().test {
                assert(awaitItem() is Status.Loading) // First emission is Loading
                assert(awaitItem() is Status.OnSuccess) // Second emission is Success
                cancelAndIgnoreRemainingEvents()
            }
        }

    @Test
    fun `fetchWebContent() should emit Loading, then Error when network error occurs`() =
        runTest {
            whenever(api.fetchWebContent()).thenThrow(RuntimeException("Network Failure"))

            repository.fetchWebContent().test {
                assert(awaitItem() is Status.Loading)
                val error = awaitItem() as Status.OnFailed
                assert(error.message.contains("Network Failure"))
                cancelAndIgnoreRemainingEvents()
            }
        }
}
