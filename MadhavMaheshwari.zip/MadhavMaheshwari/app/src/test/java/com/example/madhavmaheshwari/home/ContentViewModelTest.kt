package com.example.madhavmaheshwari.home

import androidx.arch.core.executor.testing.InstantTaskExecutorRule
import com.example.madhavmaheshwari.TestCoroutineRule
import com.example.madhavmaheshwari.dispatcherProvider
import com.example.madhavmaheshwari.home.repository.ContentRepository
import com.example.madhavmaheshwari.utils.Status
import com.example.madhavmaheshwari.utils.UIState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.test.advanceUntilIdle
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.runTest
import org.junit.After
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.mockito.Mock
import org.mockito.Mockito.`when`
import org.mockito.MockitoAnnotations

@OptIn(ExperimentalCoroutinesApi::class)
class ContentViewModelTest {
    @get:Rule
    val instantTaskExecutorRule = InstantTaskExecutorRule()

    @get:Rule
    val dispatcherRule = TestCoroutineRule()

    @Mock
    private lateinit var contentRepository: ContentRepository

    private lateinit var viewModel: ContentViewModel

    @Before
    fun setUp() {
        MockitoAnnotations.openMocks(this)
        viewModel = ContentViewModel(contentRepository, dispatcherProvider)
    }

    @After
    fun tearDown() {
        Dispatchers.resetMain()
    }

    @Test
    fun `when fetchContent() is called successfully then UI state should have success state`() =
        runTest {
            val mockResponse = "This is a test content"
            `when`(contentRepository.fetchWebContent()).thenReturn(flowOf(Status.OnSuccess(mockResponse)))
            viewModel.fetchContent()
            advanceUntilIdle()
            assert(viewModel.uiState.value == UIState.Success(mockResponse))
        }

    @Test
    fun `when fetchContent() failed then UI state should have error state`() =
        runTest {
            `when`(contentRepository.fetchWebContent()).thenReturn(flowOf(Status.OnFailed("Failed")))
            viewModel.fetchContent()
            advanceUntilIdle()
            assert(viewModel.uiState.value is UIState.Error)
        }

    @Test
    fun `when fetchWebContent throw exception then uiState should have error state`() =
        runTest {
            `when`(contentRepository.fetchWebContent()).thenThrow(RuntimeException("Network error"))

            viewModel.fetchContent()
            advanceUntilIdle()

            assert(viewModel.uiState.value is UIState.Error)
        }

    @Test
    fun `given content when find15thCharacter() is called then correct character is returned`() =
        runTest {
            val content = "abcdefghijklmnopqrst"
            val result = viewModel.find15thCharacter(content)
            assert(result == "o")
        }

    @Test
    fun `given short content when find15thCharacter() is called then it return expected error text`() =
        runTest {
            val content = "abcde"
            val result = viewModel.find15thCharacter(content)
            assert(result == "Not Enough Characters")
        }

    @Test
    fun `when findEvery15thCharacter() is called then it returns correct list`() =
        runTest {
            val content = "abcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyz"
            val result = viewModel.findEvery15thCharacter(content)
            assert(result == listOf('o', 'd', 's'))
        }

    @Test
    fun `given short content when findEvery15thCharacter() is called then it returns empty list`() =
        runTest {
            val content = "abc"
            val result = viewModel.findEvery15thCharacter(content)
            assert(result == emptyList<Char>())
        }

    @Test
    fun `when countWords() is called then countWords returns correct word count`() =
        runTest {
            val content = "Hello world, hello Kotlin world world"
            val result = viewModel.countWords(content)
            assert(result == mapOf("hello" to 2, "world," to 1, "kotlin" to 1, "world" to 2))
        }

    @Test
    fun `given content having multiple space when countWords() is called then countWords returns correct word count`() =
        runTest {
            val content = "Hello    world,     hello Kotlin    world world"
            val result = viewModel.countWords(content)
            assert(result == mapOf("hello" to 2, "world," to 1, "kotlin" to 1, "world" to 2))
        }

    @Test
    fun `given content having line break when countWords() is called then countWords returns correct word count`() =
        runTest {
            val content = "Hello  \n  world,  \n   hello \n Kotlin  \n  world world"
            val result = viewModel.countWords(content)
            assert(result == mapOf("hello" to 2, "world," to 1, "kotlin" to 1, "world" to 2))
        }

    @Test
    fun `given short content when countWords() is called then it returns empty map`() =
        runTest {
            val content = ""
            val result = viewModel.countWords(content)
            assert(result == emptyMap<String, Int>())
        }
}
