package com.example.madhavmaheshwari.utils

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties

@Composable
fun LoadingIndicator() {
    Dialog(
        onDismissRequest = { },
        DialogProperties(dismissOnBackPress = false, dismissOnClickOutside = true),
    ) {
        Box(
            modifier =
                Modifier
                    .size(96.dp)
                    .background(
                        color = Color.LightGray,
                        shape = RoundedCornerShape(4.dp),
                    ),
            contentAlignment = Alignment.Center,
        ) {
            CircularProgressIndicator(
                strokeWidth = 4.dp,
                color = Color(0xFF0F6DBE),
                modifier = Modifier.fillMaxSize(0.5f),
            )
        }
    }
}
