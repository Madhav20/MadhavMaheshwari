package com.example.madhavmaheshwari.utils

sealed class Status<out DTO : Any> {
    data class OnSuccess<out DTO : Any>(
        val response: DTO,
    ) : Status<DTO>()

    data class OnFailed(
        val message: String,
    ) : Status<Nothing>()

    object Loading : Status<Nothing>()
}
