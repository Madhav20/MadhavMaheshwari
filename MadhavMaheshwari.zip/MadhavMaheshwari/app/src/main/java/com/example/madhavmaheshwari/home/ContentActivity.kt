package com.example.madhavmaheshwari.home

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.livedata.observeAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.example.madhavmaheshwari.ui.theme.MadhavMaheshwariTheme
import com.example.madhavmaheshwari.utils.ErrorView
import com.example.madhavmaheshwari.utils.UIState
import com.example.madhavmaheshwari.utils.UIStateHandler
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MadhavMaheshwariTheme {
                MainScreen(viewModel = hiltViewModel<ContentViewModel>())
            }
        }
    }
}

@Composable
fun MainScreen(viewModel: ContentViewModel) {
    val content by viewModel.uiState.observeAsState(UIState.None)
    val result15thChar by viewModel.result15thChar.observeAsState(UIState.Loading)
    val resultEvery15thChar by viewModel.resultEvery15thChar.observeAsState(UIState.Loading)
    val wordCountMap by viewModel.wordCountMap.observeAsState(UIState.Loading)

    UIStateHandler(
        state = content,
        onSuccess = { data ->
            ContentView(
                result15thChar,
                resultEvery15thChar,
                wordCountMap,
            )
        },
        onError = { message -> ErrorView(message) },
        onNone = {
            Box(modifier = Modifier.fillMaxSize()) {
                Button(
                    modifier = Modifier.padding(12.dp).align(alignment = Alignment.Center),
                    onClick = {
                        viewModel.fetchContent()
                    },
                ) {
                    Text("Load Content", style = MaterialTheme.typography.headlineSmall)
                }
            }
        },
    )
}
