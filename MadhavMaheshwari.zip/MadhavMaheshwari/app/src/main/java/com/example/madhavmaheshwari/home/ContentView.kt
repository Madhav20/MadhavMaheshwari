package com.example.madhavmaheshwari.home

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyHorizontalGrid
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.madhavmaheshwari.utils.ErrorView
import com.example.madhavmaheshwari.utils.UIState
import com.example.madhavmaheshwari.utils.UIStateHandler

@Composable
fun ContentView(
    result15thChar: UIState<String>,
    resultEvery15thChar: UIState<List<Char>>,
    wordCountMap: UIState<Map<String, Int>>,
) {
    Column(
        modifier =
            Modifier
                .fillMaxSize()
                .padding(16.dp),
    ) {
        Spacer(modifier = Modifier.height(16.dp))

        UIStateHandler(
            state = result15thChar,
            onSuccess = { data ->
                Text(text = "15th Character: $data", style = MaterialTheme.typography.headlineSmall)
            },
            onError = { message -> ErrorView(message) },
            onNone = { },
        )

        Spacer(modifier = Modifier.height(16.dp))

        Text(text = "Every 15th Character", style = MaterialTheme.typography.headlineSmall)

        Spacer(modifier = Modifier.height(8.dp))

        UIStateHandler(
            state = resultEvery15thChar,
            onSuccess = { data -> Every15thCharacterGrid(data) },
            onError = { message -> ErrorView(message) },
            onLoading = { Text("Loading.....") },
            onNone = { },
        )

        Spacer(modifier = Modifier.height(16.dp))

        Text(text = "Word Count:", style = MaterialTheme.typography.headlineSmall)

        Spacer(modifier = Modifier.height(8.dp))

        UIStateHandler(
            state = wordCountMap,
            onSuccess = { data -> WordCountList(data) },
            onError = { message -> ErrorView(message) },
            onLoading = { Text("Loading.....") },
            onNone = { },
        )
    }
}

@Composable
fun WordCountList(wordCountMap: Map<String, Int>) {
    LazyVerticalGrid(
        columns = GridCells.Fixed(2), // Two-column grid
        modifier = Modifier.fillMaxWidth(),
        contentPadding = PaddingValues(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        items(wordCountMap.entries.toList()) { entry ->
            Card(
                modifier =
                    Modifier
                        .fillMaxWidth()
                        .padding(4.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
            ) {
                Column(modifier = Modifier.padding(8.dp)) {
                    Text(text = entry.key, style = MaterialTheme.typography.bodyLarge)
                    Text(text = "Count: ${entry.value}", style = MaterialTheme.typography.bodyMedium)
                }
            }
        }
    }
}

@Composable
fun Every15thCharacterGrid(characters: List<Char>) {
    LazyHorizontalGrid(
        rows = GridCells.Fixed(1), // Display characters in 2 rows
        modifier =
            Modifier
                .fillMaxWidth()
                .height(100.dp),
        contentPadding = PaddingValues(8.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        items(characters) { char ->
            Card(
                modifier =
                    Modifier
                        .size(50.dp) // Fixed size for each item
                        .padding(4.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
            ) {
                Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxSize()) {
                    Text(text = char.toString(), style = MaterialTheme.typography.bodyLarge)
                }
            }
        }
    }
}
