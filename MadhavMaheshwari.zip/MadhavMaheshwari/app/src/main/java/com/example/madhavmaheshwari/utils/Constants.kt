package com.example.madhavmaheshwari.utils

object Constants {
    const val BASE_URL = "https://www.truecaller.com/"
}
