package com.example.madhavmaheshwari.home.repository

import com.example.madhavmaheshwari.home.ContentApi
import com.example.madhavmaheshwari.utils.DispatcherProvider
import com.example.madhavmaheshwari.utils.Status
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import javax.inject.Inject

class ContentRepositoryImpl
    @Inject
    constructor(
        private val contentApi: ContentApi,
        private val dispatcherProvider: DispatcherProvider,
    ) : ContentRepository {
        override suspend fun fetchWebContent(): Flow<Status<String>> =
            flow {
                emit(Status.Loading)
                try {
                    val response = contentApi.fetchWebContent()
                    if (response.isSuccessful) {
                        val content = response.body()
                        if (!content.isNullOrBlank()) {
                            emit(Status.OnSuccess(content))
                        } else {
                            emit(Status.OnFailed("An Unknown error has occurred"))
                        }
                    }
                } catch (e: Exception) {
                    emit(Status.OnFailed(e.message.toString()))
                }
            }.flowOn(dispatcherProvider.io)
    }
