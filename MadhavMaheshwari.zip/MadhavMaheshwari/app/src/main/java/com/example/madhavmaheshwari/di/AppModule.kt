package com.example.madhavmaheshwari.di

import android.content.Context
import com.example.madhavmaheshwari.home.ContentApi
import com.example.madhavmaheshwari.home.repository.ContentRepository
import com.example.madhavmaheshwari.home.repository.ContentRepositoryImpl
import com.example.madhavmaheshwari.utils.ConnectivityCheckInterceptor
import com.example.madhavmaheshwari.utils.Constants
import com.example.madhavmaheshwari.utils.DispatcherProvider
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.scalars.ScalarsConverterFactory
import java.util.concurrent.TimeUnit
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {
    @Singleton
    @Provides
    fun provideDispatchers(): DispatcherProvider =
        object : DispatcherProvider {
            override val main: CoroutineDispatcher
                get() = Dispatchers.Main
            override val io: CoroutineDispatcher
                get() = Dispatchers.IO
            override val default: CoroutineDispatcher
                get() = Dispatchers.Default
            override val unconfined: CoroutineDispatcher
                get() = Dispatchers.Unconfined
        }

    @Provides
    @Singleton
    fun provideRetrofit(
        @ApplicationContext context: Context,
    ): Retrofit =
        Retrofit
            .Builder()
            .baseUrl(Constants.BASE_URL)
            .client(provideOkHttpClient(context))
            .addConverterFactory(ScalarsConverterFactory.create())
            .build()

    private fun provideOkHttpClient(
        @ApplicationContext context: Context,
    ): OkHttpClient =
        OkHttpClient
            .Builder()
            .readTimeout(20L, TimeUnit.SECONDS)
            .apply {
                val httpLoggingInterceptor =
                    HttpLoggingInterceptor()
                httpLoggingInterceptor.setLevel(HttpLoggingInterceptor.Level.HEADERS)

                httpLoggingInterceptor.setLevel(HttpLoggingInterceptor.Level.BODY)
                addNetworkInterceptor(httpLoggingInterceptor)
                addInterceptor(ConnectivityCheckInterceptor(context))
            }.build()

    @Provides
    @Singleton
    fun provideContentApi(retrofit: Retrofit) = retrofit.create(ContentApi::class.java)

    @Provides
    @Singleton
    fun provideContentRepository(
        api: ContentApi,
        dispatcherProvider: DispatcherProvider,
    ): ContentRepository = ContentRepositoryImpl(api, dispatcherProvider)
}
