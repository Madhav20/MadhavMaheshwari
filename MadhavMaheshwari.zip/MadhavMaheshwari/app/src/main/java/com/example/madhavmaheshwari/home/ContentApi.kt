package com.example.madhavmaheshwari.home

import retrofit2.Response
import retrofit2.http.GET

interface ContentApi {
    @GET("blog/life-at-truecaller/life-as-an-android-engineer")
    suspend fun fetchWebContent(): Response<String>
}
