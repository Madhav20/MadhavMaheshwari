package com.example.madhavmaheshwari.utils

import androidx.annotation.StringRes
import javax.annotation.concurrent.Immutable

@Immutable
sealed class UIState<out T : Any> {
    @Immutable
    object Loading : UIState<Nothing>()

    @Immutable
    object None : UIState<Nothing>()

    @Immutable
    data class Success<T : Any>(
        val data: T,
    ) : UIState<T>()

    @Immutable
    data class Error(
        @StringRes val message: Int,
        val helperText: String? = null,
    ) : UIState<Nothing>()
}
