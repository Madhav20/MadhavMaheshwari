package com.example.madhavmaheshwari.utils

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource

@Composable
fun <T : Any> UIStateHandler(
    state: UIState<T>,
    onSuccess: @Composable (T) -> Unit,
    onError: @Composable (String) -> Unit = { message ->
        ErrorView(message)
    },
    onLoading: @Composable () -> Unit = { LoadingIndicator() },
    onNone: @Composable () -> Unit,
) {
    when (state) {
        is UIState.Error -> onError(stringResource(state.message))
        UIState.Loading -> onLoading()
        UIState.None -> onNone()
        is UIState.Success -> onSuccess(state.data)
    }
}

@Composable
fun ErrorView(message: String) {
    Text(
        text = message,
        style = MaterialTheme.typography.bodySmall,
        color = Color.Red,
    )
}
