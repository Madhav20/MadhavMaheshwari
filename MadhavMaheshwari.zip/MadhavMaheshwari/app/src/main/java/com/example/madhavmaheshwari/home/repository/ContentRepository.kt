package com.example.madhavmaheshwari.home.repository

import com.example.madhavmaheshwari.utils.Status
import kotlinx.coroutines.flow.Flow

interface ContentRepository {
    suspend fun fetchWebContent(): Flow<Status<String>>
}
